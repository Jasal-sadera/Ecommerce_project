import { useContext } from "react"
import axios from "axios";
import { ToastContainer,toast } from "react-toastify";
import { Auth_checking } from "../App";
import { Signin } from "./SERVICES";



export default function LOGIN(){

    
   

    const handler = (e) =>{
        e.preventDefault();
        let json = {
            username:e.target[0].value,
            password1:e.target[1].value,
        }

        const fetchData = async() =>{
            try{
                const res = await Signin(json);
                console.log(res.data);
                localStorage.setItem('token',res.data.accessToken);
                localStorage.setItem('role',res.data.roles);
                localStorage.setItem('name',res.data.username);
                setTimeout(() => {
        
                    window.location.replace('/products');
                  }, 2000);
                toast("successfully logged in")

            }catch(error){
                toast("error in login..");
                console.log("error fetching data: "+error);
            }
        }
        fetchData();
    };


const ss = {
    marginTop: '-150px',
    background:' hsla(0, 0%, 100%, 0.8)',
    backdropFilter: 'blur(30px)',
}
const s ={
    
    backgroundImage: 'url("https://mdbootstrap.com/img/new/textures/full/171.jpg")',
    height: '300px',
}

    return (
  




/* <section class="text-center">
  
  <div class="p-5 bg-image" style={s}></div>
 
  <div class="card mx-4 mx-md-5 shadow-5-strong" style={ss}>
    <div class="card-body py-5 px-md-5">

      <div class="row d-flex justify-content-center">
        <div class="col-lg-8">
          <h2 class="fw-bold mb-5">LogIn now</h2>
          <form onSubmit={handler} >
            
         

            
            <div class="form-outline mb-4">
              <input type="text" id="form3Example3" class="form-control" required />
              <label class="form-label" for="form3Example3">Username</label>
            </div>

           
            <div class="form-outline mb-4">
              <input type="password" id="form3Example4" class="form-control" required />
              <label class="form-label" for="form3Example4">Password</label>
            </div>

           
           

           
            <button type="submit" class="btn btn-primary btn-block mb-4">
             LogIn
            </button>
        <ToastContainer />
            
            <div class="text-center">
              <p>Don't have account:</p>
             <a href="/registeration">Register Here</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section> */




<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style={{borderRadius: '1rem'}}>
          <div class="card-body p-5 text-center">
        <form onSubmit={handler}>
            <div  class=" mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
              <p class="text-white-50 mb-5">Please enter your login and password!</p>

              <div class="form-outline form-white mb-4">
                <input type="text" id="typeEmailX" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Username</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

             

              <button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button>

           

            </div>
            </form>
            <div>
              <p class="mb-0">Don't have an account? <a href="#!" class="text-white-50 fw-bold">Sign Up</a>
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>



    );
}