import { useContext } from "react";
import { ToastContainer, toast } from "react-toastify";

import axios from "axios";
import { Signup } from "./SERVICES";


export default function REGISTERATION(){


  
const handleSubmit=async (e)=>{
    e.preventDefault();

    let jsonObj = {
        username: e.target[0].value,
    password1: e.target[2].value,
    email: e.target[1].value,
    
    }

    try{
        const response = await Signup(jsonObj);
       console.log(response.data);
       localStorage.clear()
        setTimeout(() => {
        
            window.location.replace('/login');
          }, 3000);
          
          toast("User registered successfully...")
    }catch{
        toast("User already exist.")
    }


}

const ss = {
    marginTop: '-150px',
    background:' hsla(0, 0%, 100%, 0.8)',
    backdropFilter: 'blur(30px)',
}
const s ={
    
    backgroundImage: 'url("https://mdbootstrap.com/img/new/textures/full/171.jpg")',
    height: '300px',
}
    return (

        


// <section class="text-center">
//   <div class="p-5 bg-image" style={s}></div>

//   <div class="card mx-4 mx-md-5 shadow-5-strong" style={ss}>
//     <div class="card-body py-5 px-md-5">

//       <div class="row d-flex justify-content-center">
//         <div class="col-lg-8">
//           <h2 class="fw-bold mb-5">Sign up now</h2>
//           <form onSubmit={handleSubmit}>
//             <div class="row">
//               <div class="col-md-6 mb-4">
//                 <div class="form-outline">
//                   <input type="text" id="form3Example1" class="form-control" required/>
//                   <label class="form-label" for="form3Example1">Username</label>
//                 </div>
//               </div>
//               <div class="col-md-6 mb-4">
//                 <div class="form-outline">
//                   <input type="email" id="form3Example2" class="form-control" required />
//                   <label class="form-label" for="form3Example2">Email</label>
//                 </div>
//               </div>
//             </div>
          
//               <div class="col-md-6 mb-4">
//                 <div class="form-outline">
                
//               </div>
//             </div>
//             <div class="row">
             
             
//               <div class="form-outline">
//                   <input type="password" id="form3Example2" class="form-control" required/>
//                   <label class="form-label" for="form3Example2">Password</label>
//                 </div>
              
//             </div>

           

          

//             <button type="submit" class="btn btn-primary btn-block mb-4">
//               Sign up
//             </button>
//             <ToastContainer />

//             <div class="text-center">
//               <p>Already have a account: </p>
//               <a href="/login">Login here</a>
//             </div>
//           </form>
//         </div>
//       </div>
//     </div>
//   </div>
// </section>






<section class="vh-100 gradient-custom">
  <div class="container  h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style={{borderRadius: '1rem'}}>
          <div class="card-body p-5 text-center">
        <form onSubmit={handleSubmit}>
            <div  class="  pb-3">

              <h2 class="fw-bold mb-2 text-uppercase">Signup</h2>
              <p class="text-white-50 mb-5">Please enter your Registeration Details !</p>

              <div class="form-outline form-white mb-4">
                <input type="text" id="typeEmailX" class="form-control form-control-lg" required />
                <label class="form-label" for="typeEmailX">Username</label>
              </div>
              <div class="form-outline form-white mb-4">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" required />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

             

              <button class="btn btn-outline-light btn-lg px-5" type="submit">Signup</button>

           

            </div>
            </form>
            <div>
              <p class="mb-0">Don't have an account? <a href="#!" class="text-white-50 fw-bold">Sign Up</a>
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    )
}