import { useState,useEffect } from "react"
import NavbarUser from "./NavUsr"
import PRODUCT from "./PRODUCT"
import { listProd } from "./SERVICES";
import { startTransition } from "react";
export default function User(props){

    useEffect(() => {
        startTransition(() => {
            fetchData();
        });
      }, []);
    
      const [prods,setprods] = useState([]);
      
      const fetchData = ()=>{
        listProd()
        .then(response =>{
          console.log(response.data);
          console.log("allprod")
          setprods(response.data);
          
          
        })
         .catch(error => {
          console.log(error);
      });
      }
      const [searchQuery, setSearchQuery] = useState('');
      const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
      };

      const filterProducts = () => {
        return prods.filter(product =>
          product.productName.toLowerCase().includes(searchQuery.toLowerCase())
        );
      };
   
    
var url;
    
    return(
       
        <div>
            <NavbarUser username={props.username}/>
        <div className="mt-3 container">
        
          
                <input type="text" className="form-control" placeholder="search any product here"  value={searchQuery}
        onChange={handleSearchChange} />
               
        </div>
        

        <div className="justify-content-center row mt-2 ">
            <h3 className="text-center text-white p-3 ">Available Products</h3>
      
    {filterProducts().map((p)=>(
       url = `https://source.unsplash.com/featured/?${encodeURIComponent(p.productName)}` ,

      
       <div class="card cd">
      <div class="card-body">
      <img class="card-img-top" src={url} alt="Card image cap" width="250px" height="250px"/>
      <h5 class="card-title mt-2">ProdId: {p.productId}</h5>

       <h5 class="card-title">ProdName: {p.productName}</h5>
       <h6 class="card-subtitle mb-2 text-muted">Price: &#8377;{p.price}</h6>
       <p class="card-text">Category: {p.categoryName}</p>
       <p class="card-text">Description: {p.des}</p>
        
       
      </div>
       
</div>
       
    ))}
   


</div>
 
 </div>
    )
}