import { useState } from "react";
export default function Navbar(){
  const [menuOpen, setMenuOpen] = useState(false);
    return (
        <div>
        <nav class="navbar navbar-expand-lg navbar-light prodbtn p-3">
   <a class="navbar-brand text-light tx" href="/products">E-COMMERCE</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"
   onClick={() => setMenuOpen(!menuOpen)}
   >
     <span class="navbar-toggler-icon"></span>
   </button>
   <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")}  id="navbarNavDropdown">
     <ul class="navbar-nav ms-auto justify-content-center">
     <li class="nav-item active">
         <a class="nav-link nvl " href="/products">Home</a>
       </li>
     
       <li class="nav-item">
         <a class="nav-link nvl" href="/products">Products</a>
       </li>
       <li class="nav-item">
         <a class="nav-link nvl" href="/categories">Categories</a>
       </li>
       <li class="nav-item">
         <a class="nav-link nvl" href="/about">About</a>
       </li>
       <li class="nav-item">
       <a class="nav-link nvl" href="/logout">Logout</a>
       </li>
      
     </ul>
   </div>
 </nav>
 </div>
    )
}

// import React, { useState } from "react";

// import { NavLink } from "react-router-dom";

// import { IoIosLogOut } from "react-icons/io";

// export default function Navbar  ()  {
//   const [menuOpen, setMenuOpen] = useState(false);

//   return (
//     <nav className="navbar navbar-expand-lg navbar-light prodbtn p-3">
//       <a className="navbar-brand text-light tx" href="/products">
//         E-COMMERCE
//       </a>
//       <button
//         className="navbar-toggler"
//         type="button"
//         data-toggle="collapse"
//         data-target="#navbarNavDropdown"
//         aria-controls="navbarNavDropdown"
//         aria-expanded="false"
//         aria-label="Toggle navigation"
//         onClick={() => setMenuOpen(!menuOpen)}
//       >
//         <span className="navbar-toggler-icon"></span>
//       </button>
//       <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")}>
//         <ul className="navbar-nav ms-auto justify-content-center">
//           <li className="nav-item active">
//             <NavLink to="/products" className="nav-link nvl">
//               Home
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/products" className="nav-link nvl">
//               Products
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/categories" className="nav-link nvl">
//               Categories
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/about" className="nav-link nvl">
//               About
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/" className="nav-link nvl">
//             Logout <IoIosLogOut /> 
//             </NavLink>
//           </li>
          
         
//         </ul>
//       </div>
//     </nav>
//   );
// };
