import NavbarHome from './NavbarHome'
import homegif from './img/homegif.gif'

import React from 'react'
export default function Home(){
	localStorage.clear();
  const ss = {
    marginTop: '100px',
    background:' hsla(0, 0%, 100%, 0.8)',
    backdropFilter: 'blur(30px)',
   
}
    return (



/* <section class="background-radial-gradient overflow-hidden">
<NavbarHome />	

  <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-3">
    <div class="row gx-lg-5 align-items-center mb-5">
      <div class="col-lg-6 mb-5 mb-lg-0" style={{zIndex:'10'}}>
        <h1 class="my-5 display-5 fw-bold ls-tight" style={{color: 'hsl(218, 81%, 95%)'}}>
        Click, shop, smile <br />
          <span style={{color: 'hsl(218, 81%, 75%)'}}> – it's that easy</span>
        </h1>
        <p class="mb-4 opacity-70" style={{color: 'hsl(218, 81%, 85%)'}}>
        Don’t forget about those people who have spent their hard-earned money with you. They could be responsible for substantial online sales later down the line. Treat them like your family and take them with you on your journey.
        </p>
        <div>
      <a href='/registeration' className='btn btn-primary m-3'>SignUp</a>
           <a href='/login' className='btn btn-warning m-3 '>LogIn</a>
   </div>
        
      </div>

      <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
        <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
        <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

        <div class="card bg-glass background-radial-gradient  "   >
          <div class=" card-body px-4 py-5 px-md-5 " >
          <img className="border border-2" src={ecom} width="400vh" height="440vh" ></img>
          </div>
         
        </div>
       
      </div>
    </div>
  </div>
</section> */



<section class="">
<NavbarHome />
  <div class="px-4 py-5 px-md-5 text-center text-lg-start" style={{backgroundColor: 'hsl(0, 0%, 96%)'}}>
    <div class="container">
      <div class="row gx-lg-5 align-items-center">
        <div class="col-lg-6 mb-5 mb-lg-0">
          <h1 class="my-5 display-3 fw-bold ls-tight">
            The best offer <br />
            <span class="text-primary">for your business</span>
          </h1>
          <p style={{color: "hsl(217, 10%, 50.8%)"}}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Eveniet, itaque accusantium odio, soluta, corrupti aliquam
            quibusdam tempora at cupiditate quis eum maiores libero
            veritatis? Dicta facilis sint aliquid ipsum atque?
          </p>
        </div>

        <div class="col-lg-6 mb-5 mb-lg-0">
          <div class="card">
            <div class="card-body text-center py-5 px-md-5">
             <img src={homegif} width="370px"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>






    )
}