import axios from "axios";

const API_URL_Product = 'http://localhost:8060/ecomm/api/v1/product';
const API_URL_Category = 'http://localhost:8060/ecomm/category';

const API_URL_Signup = 'http://localhost:8060/api/auth/signup';
const API_URL_Signin = 'http://localhost:8060/api/auth/signin';


export function Signup(data){
    return axios.post(API_URL_Signup,data);
}

export function Signin(data){
    return axios.post(API_URL_Signin,data);
}



//product URL

//add product
export function addProd(data){
    return axios.post(API_URL_Product+'/addproduct',data);
}

//List product
export function listProd(){
    return axios.get(API_URL_Product+'/products')
}

//get prod by id
export function getProdById(id,data){
    return axios.get(API_URL_Product+`/productbyid?id=${id}`,data)
}

//get prod by name
export function getProdByName(name,data){
    return axios.get(API_URL_Product+`/productbyname?name=${name}`,data)
}

//update prod by id

export function updateProdById(id,data){
    return axios.post(API_URL_Product +`/updateproduct?id=${id}`,data);
}

//update prod by name

export function updateProdByName(na,data){
    return axios.post(API_URL_Product+`/updateproduct?name=${na}`,data);
}

//delete product
export function deleteProd(id,data){
    return axios.post(API_URL_Product+`/deleteproduct?id=${id}`,data);
}

//***category urls

//add category
export function addCategory(data){
    return axios.post(API_URL_Category+'/addcategory',data);
}

//list all category
export function listCategory(){
    return axios.get(API_URL_Category+'/categories');
}

//get category by id
export function getCategoryById(id){
    return axios.get(API_URL_Category+`/categorybyid?id=${id}`);
}

//get category by name
export function getCategoryByName(name){
    return axios.get(API_URL_Category+`/categorybyname?name=${name}`);
}

//update by id
export function updateCategoryById(id,data){
    return axios.post(API_URL_Category+`/updatecategory?id=${id}`,data);
}

//update by name
export function updatecategoryByName(nam,data){
    return axios.post(API_URL_Category+`/updatecategory?name=${nam}`,data);
}

//delete category
export function deleteCategory(id,data){
    return axios.post(API_URL_Category+`/deletecategory?id=${id}`,data);
}