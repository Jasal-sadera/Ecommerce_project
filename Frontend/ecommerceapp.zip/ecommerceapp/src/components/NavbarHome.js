import { useState } from "react";
export default function NavbarHome(){
  const [menuOpen, setMenuOpen] = useState(false);
    return (
        <div>
        <nav class="navbar navbar-expand-lg navbar-dark prodbtn p-3"  >
   <a class="navbar-brand text-light tx" href="/">Shopper's Hault</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"
   onClick={() => setMenuOpen(!menuOpen)}
   >
     <span class="navbar-toggler-icon"></span>
   </button>
   <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")} >
     <ul class="navbar-nav ms-auto justify-content-center">
     <li class="nav-item active">
         <a class="nav-link nvl text-light" href="/">Home</a>
       </li>
       <li class="nav-item active">
         <a class="nav-link nvl text-light" href="/registeration">Signup</a>
       </li>
       <li class="nav-item">
         <a class="nav-link nvl text-light" href="/login">Login</a>
       </li>
       <li class="nav-item">
         <a class="nav-link nvl text-light" href="/">Contact</a>
       </li>
      
       <li class="nav-item">
         <a class="nav-link nvl text-light" href="/about">About</a>
       </li>
      
     </ul>
   </div>
 </nav>
 </div>
    );
    }

// import React, { useState } from "react";
// import { FaUserCircle } from "react-icons/fa";
// import { NavLink ,Link} from "react-router-dom";
// import { FaCartArrowDown } from "react-icons/fa";
// import { IoIosLogOut } from "react-icons/io";

// export  const NavbarHome = (props) => {
//   const [menuOpen, setMenuOpen] = useState(false);

//   return (
//     <nav className="navbar navbar-expand-lg navbar-light background-radial-gradient p-3">
//       <Link to="/" className="navbar-brand text-light tx">
//         E-COMMERCE
//       </Link>
//       <button
//         className="navbar-toggler"
//         type="button"
//         data-toggle="collapse"
//         data-target="#navbarNavDropdown"
//         aria-controls="navbarNavDropdown"
//         aria-expanded="false"
//         aria-label="Toggle navigation"
//         onClick={() => setMenuOpen(!menuOpen)}
//       >
//         <span className="navbar-toggler-icon"></span>
//       </button>
//       <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")}>
//         <ul className="navbar-nav ms-auto justify-content-center">
//           <li className="nav-item active">
//             <NavLink to="/" className="nav-link nvl text-light">
//               Home
//             </NavLink>
//           </li>
//           <li className="nav-item active">
//             <NavLink
//               to="/registeration"
//               className="nav-link nvl text-light"
//             >
//               Registeration
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/login" className="nav-link nvl text-light">
//               Login
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/" className="nav-link nvl text-light">
//               Contact
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/about" className="nav-link nvl text-light">
//               About
//             </NavLink>
//           </li>
//           {/* <li className="nav-item">
//             <NavLink to="/cart" className="nav-link nvl text-light">
//               <FaCartArrowDown />
//             </NavLink>
//           </li> */}
//           {/* <li className="nav-item">
//             <NavLink to="/" className="nav-link nvl text-light">
//               <FaUserCircle />
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/" className="nav-link nvl text-light">
//               <IoIosLogOut />
//             </NavLink>
//           </li> */}
//         </ul>
//       </div>
//     </nav>
//   );
// };
